from flask import Blueprint, jsonify, request
from flask_cors import cross_origin
from src.models.user import db
from src.models.show import Show
from datetime import datetime

show_bp = Blueprint('show', __name__)

@show_bp.route('/shows', methods=['GET'])
@cross_origin()
def get_shows():
    # Parâmetros de busca
    search = request.args.get('search', '')
    situacao = request.args.get('situacao', '')
    
    query = Show.query
    
    # Filtro de busca por nome ou show
    if search:
        query = query.filter(
            (Show.nome.ilike(f'%{search}%')) | 
            (Show.show.ilike(f'%{search}%'))
        )
    
    # Filtro por situação
    if situacao:
        query = query.filter(Show.situacao.ilike(f'%{situacao}%'))
    
    # Ordenar por data do show (mais recente primeiro)
    shows = query.order_by(Show.data_show.desc()).all()
    
    return jsonify([show.to_dict() for show in shows])

@show_bp.route('/shows', methods=['POST'])
@cross_origin()
def create_show():
    try:
        data = request.json
        
        # Converter string de data para objeto date
        data_show = datetime.strptime(data['data_show'], '%Y-%m-%d').date()
        
        show = Show(
            nome=data['nome'],
            show=data['show'],
            data_show=data_show,
            valor_cache=float(data['valor_cache']),
            situacao=data['situacao'],
            observacao=data.get('observacao', '')
        )
        
        db.session.add(show)
        db.session.commit()
        
        return jsonify(show.to_dict()), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@show_bp.route('/shows/<int:show_id>', methods=['GET'])
@cross_origin()
def get_show(show_id):
    show = Show.query.get_or_404(show_id)
    return jsonify(show.to_dict())

@show_bp.route('/shows/<int:show_id>', methods=['PUT'])
@cross_origin()
def update_show(show_id):
    try:
        show = Show.query.get_or_404(show_id)
        data = request.json
        
        show.nome = data.get('nome', show.nome)
        show.show = data.get('show', show.show)
        
        if 'data_show' in data:
            show.data_show = datetime.strptime(data['data_show'], '%Y-%m-%d').date()
        
        if 'valor_cache' in data:
            show.valor_cache = float(data['valor_cache'])
        
        show.situacao = data.get('situacao', show.situacao)
        show.observacao = data.get('observacao', show.observacao)
        
        db.session.commit()
        
        return jsonify(show.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@show_bp.route('/shows/<int:show_id>', methods=['DELETE'])
@cross_origin()
def delete_show(show_id):
    show = Show.query.get_or_404(show_id)
    db.session.delete(show)
    db.session.commit()
    return '', 204

@show_bp.route('/shows/situacoes', methods=['GET'])
@cross_origin()
def get_situacoes():
    """Retorna as situações únicas existentes no banco"""
    situacoes = db.session.query(Show.situacao).distinct().all()
    return jsonify([s[0] for s in situacoes if s[0]])

