from src.models.user import db
from datetime import datetime

class Show(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    show = db.Column(db.String(200), nullable=False)
    data_show = db.Column(db.Date, nullable=False)
    valor_cache = db.Column(db.Float, nullable=False)
    situacao = db.Column(db.String(50), nullable=False)
    observacao = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self):
        return f'<Show {self.nome} - {self.show}>'

    def to_dict(self):
        return {
            'id': self.id,
            'nome': self.nome,
            'show': self.show,
            'data_show': self.data_show.isoformat() if self.data_show else None,
            'valor_cache': self.valor_cache,
            'situacao': self.situacao,
            'observacao': self.observacao,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

